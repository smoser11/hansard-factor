#ifndef _NBFACTOR_NBFACTOR_H
#define _NBFACTOR_NBFACTOR_H

#include <RcppArmadillo.h>

RcppExport SEXP NBfactor() ;

#endif
