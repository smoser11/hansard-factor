NBfactor <- function(Ys, RPrior, RInitial, ntopic, Ndrawn, Nburnn) {
    .Call('CombFactor_NBfactor', PACKAGE = 'CombFactor', Ys, RPrior, RInitial, ntopic, Ndrawn, Nburnn)
}
