#ifndef _COMBFACTOR_NBFACTOR_H
#define _COMBFACTOR_NBFACTOR_H

#include <RcppArmadillo.h>

RcppExport SEXP NBfactor() ;

#endif
