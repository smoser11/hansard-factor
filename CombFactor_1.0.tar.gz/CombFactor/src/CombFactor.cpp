#include "CombFactor.h"
#include "NBfactor.h"
#include <iostream>

#include "RNG.h"
#include "PolyaGamma.hpp"
#include <exception>

#ifdef USE_R
#include "R.h"
#include "Rmath.h"
#endif

using namespace Rcpp ;
using namespace RcppArmadillo;
using namespace std;

void rpg_devroye(double *x, int *n, double *z, int *num)
{
  
  RNG r;
  PolyaGamma pg;

  #ifdef USE_R
  GetRNGstate();
  #endif

  for(int i=0; i < *num; ++i){
    x[i] = pg.draw(n[i], z[i], r);
  }

  #ifdef USE_R
  PutRNGstate();
  #endif
  
} // rpg

// [[Rcpp::export]]
SEXP CombFactor(SEXP Ycont, SEXP Yc, SEXP Ys, SEXP RPrior, SEXP RInitial, int ntopic, int Ndrawn, int Nburnn){
  
	

	Rcpp::NumericMatrix Yr(Ys); 				//	Create Rcpp matrix from SEXP
	int N = Yr.nrow(), P = Yr.ncol();			//	dim(YY)

	arma::mat YY(Yr.begin(), N, P, false);   	// reuses memory and avoids extra copy

	// N Observations, each has Pb binomial trials
	Rcpp::NumericMatrix Ycr(Yc);
	int Pl = Ycr.ncol();
	arma::mat YYl(Ycr.begin(), N, Pl, false);


	//arma::colvec YYl(Ycr.begin(),N,false);
	
	Rcpp::NumericMatrix Ycontr(Ycont);
	int Pc = Ycontr.ncol();
	arma::mat YYc(Ycontr.begin(),N,Pc,false);


	int K = ntopic; 								//	No of topics



	// Parameter Setting Prior

	Rcpp::List Prior(RPrior);

	// for continuous Prior
	// Model:
	// ConY_ij ~ N(alpha_j + gamma_i+B_j*f_i)
	double a_c = Rcpp::as<double>(Prior["a_c"]);
	double niu_a_c = Rcpp::as<double>(Prior["niu_a_c"]);
	double niu_alpha_c = Rcpp::as<double>(Prior["niu_alpha_c"]);
	Rcpp::NumericVector mean_alphaR = Prior["mean_alpha"];
	arma::rowvec mean_alpha(mean_alphaR.begin(),P,false);


	Rcpp::NumericVector niuR_c = Prior["niu_c"];
	arma::colvec niu_b_c(niuR_c.begin(),K,false);

	double nu0 = Rcpp::as<double>(Prior["nu0"]);
	double s02 = Rcpp::as<double>(Prior["s02"]);

	//double nu0 = 3.0;
	//double s02 = 1.0;
	//double niu_alpha_c = 1.0;
	//arma::colvec niu_b_c(K);
	//niu_b_c.fill(10.0);

	// for Logistic Prior

	//Model:
	//P(YYc_ij =1) = p_ij   Psi_ij = exp(p_ij)/(1+exp(p_ij))
	// Psi_ij = alpha_j + gamma_i + sum_1toK(B_j*f_j)
	// Z_ij = 2y_ij-1/2w_ij   Z_ij ~ N(alpha_l + sum_1toK(B_j*f_j), w_i^{-1})
	// w_ij ~PG(1,Psi_ij)

	// Prior:
	// alpha_l ~N(0,niu_alpha_l)
	// gamma_l ~N(a_l, 1)
	// a_l ~ N(0,niu_a_l)
	// B_k ~ N(0, niu_b_l_k) 
	double a_l = Rcpp::as<double>(Prior["a_l"]);
	double niu_a_l = Rcpp::as<double>(Prior["niu_a_l"]);
	double niu_alpha_l = Rcpp::as<double>(Prior["niu_alpha_l"]);

	Rcpp::NumericVector niuR_l = Prior["niu_l"];
	arma::colvec niu_b_l(niuR_l.begin(),K,false);

	// for Negative Binomial

	
	Rcpp::NumericMatrix Vr = Prior["V"];
	arma::mat V(Vr.begin(),K,K,false);

	Rcpp::NumericMatrix V0r = Prior["V0"];
	arma::mat V0(V0r.begin(),K,K,false);

	double a = Rcpp::as<double>(Prior["a"]);
	double h = Rcpp::as<double>(Prior["h"]);
	int niu_a = Rcpp::as<int>(Prior["niu_a"]);
	int niu_alpha = Rcpp::as<int>(Prior["niu_alpha"]);

	Rcpp::NumericVector niuR = Prior["niu"];
	arma::colvec niu(niuR.begin(),K,false);

	Rcpp::NumericVector qR = Prior["q"];
	arma::colvec q(qR.begin(),K,false);

	double c_s = Rcpp::as<double>(Prior["c_s"]);
	double d_s = Rcpp::as<double>(Prior["d_s"]);




	// Initialization

	//Negative Binomial

	Rcpp::List Initial = RInitial;

	Rcpp::NumericVector drawsB = Initial["B"];
	arma::mat B(drawsB.begin(),P,K,false);

	Rcpp::NumericVector drawsf = Initial["f"];
	arma::mat f(drawsf.begin(),N,K,false);

	//cout << "\n f(100,1) = "<<f(100,1);
	
	Rcpp::NumericVector drawsal = Initial["alpha"];
	arma::rowvec alpha(drawsal.begin(),P,false);
	Rcpp::NumericVector drawga = Initial["gamma"];
	arma::colvec gamma(drawga.begin(),N,false);


	arma::mat Psi = arma::zeros(N,P);
	arma::mat Omega = arma::zeros(N,P);
	arma::mat Z = arma::zeros(N,P);
	arma::mat zhat = arma::zeros(N,P);

	// Logistic
	Rcpp::NumericVector drawsB_l = Initial["B_l"];
	arma::mat B_l(drawsB_l.begin(),Pl,K,false);
	
	Rcpp::NumericVector drawsal_l = Initial["alpha_l"];
	arma::rowvec alpha_l(drawsal_l.begin(),Pl,false);
	Rcpp::NumericVector drawga_l = Initial["gamma_l"];
	arma::colvec gamma_l(drawga_l.begin(),N,false);

	arma::mat Phi = arma::zeros(N,Pl);
	arma::mat Omega_l = arma::zeros(N,Pl);
	arma::mat Z_l = arma::zeros(N,Pl);
	arma::mat zhat_l = arma::zeros(N,Pl);

	// Continuous
	Rcpp::NumericVector drawsB_c = Initial["B_c"];
	arma::mat B_c(drawsB_c.begin(),Pc,K,false);
	
	Rcpp::NumericVector drawsal_c = Initial["alpha_c"];
	arma::rowvec alpha_c(drawsal_c.begin(),Pc,false);
	Rcpp::NumericVector drawga_c = Initial["gamma_c"];
	arma::colvec gamma_c(drawga_c.begin(),N,false);
	
	arma::mat Phi_c = arma::zeros(N,Pc);
	arma::mat Delta_c = arma::ones(N,Pc);


	arma::rowvec comb_alpha(P+Pl+Pc);
	comb_alpha(arma::span(0,(P-1))) = alpha;
	comb_alpha(arma::span(P,(P+Pl-1))) = alpha_l;
	comb_alpha(arma::span((P+Pl),(P+Pl+Pc-1))) = alpha_c;

	arma::mat comb_Z(N,(P+Pl+Pc));
	comb_Z(arma::span(0,(N-1)),arma::span(0,(P-1))) = Z;
	comb_Z(arma::span(0,(N-1)),arma::span(P,(P+Pl-1))) = Z_l;
	comb_Z(arma::span(0,(N-1)),arma::span((P+Pl),(P+Pl+Pc-1))) = YYc;



	arma::mat comb_B((P+Pl+Pc),K);
	comb_B(arma::span(0,(P-1)),arma::span(0,(K-1))) = B;
	comb_B(arma::span(P,(P+Pl-1)),arma::span(0,(K-1))) = B_l;
	comb_B(arma::span((P+Pl),(P+Pl+Pc-1)),arma::span(0,(K-1))) = B_c;

	arma::mat comb_Omega(N,(P+Pl+Pc));
	comb_Omega(arma::span(0,(N-1)),arma::span(0,(P-1))) = Omega;
	comb_Omega(arma::span(0,(N-1)),arma::span(P,(P+Pl-1))) = Omega_l;
	comb_Omega(arma::span(0,(N-1)),arma::span((P+Pl),(P+Pl+Pc-1))) = Delta_c;



	//Gibbs Sampler
	//int Ndrawn = 5; 
	//int Nburnn = 0;

	// Store Parameter
	arma::cube BBn = arma::zeros((P+Pl+Pc),K,Ndrawn);
	arma::cube FFn = arma::zeros(N,K,Ndrawn);

	arma::mat Alfn = arma::zeros((P+Pl+Pc),Ndrawn);
	arma::cube Gamn = arma::zeros(N,3,Ndrawn);
	//arma::mat Gamn = arma::zeros(N,Ndrawn);

	// Logistic
	//arma::mat BBn_l = arma::zeros(K,Ndrawn);
	//arma::colvec Alfn_l = arma::zeros(Ndrawn);

	double test;

   // cout << "\n f(100,1) = "<<f(100,1);
    

	//Iteration
	for (int iter = 0; iter < (Ndrawn+Nburnn); ++iter)
	{
		//Calculate Psi
		for (int i = 0; i < N; ++i)
		{
			arma::rowvec temp(P);
			temp.fill(gamma(i));
			Psi.row(i) = alpha + temp + arma::trans(B*arma::trans(f.row(i))); 
		}

		//Sample omega
		for (int i = 0; i < N; ++i)
		{
			for (int j = 0; j < P; ++j)
			{
        
          double *xx;
          int *nn;
          double *zz;
          int *numm;
    
          double xxx=0.5;
          int nnn=YY(i,j)+h;
          double zzz=Psi(i,j);
          int numnum=1;
    
          xx=&xxx;
          nn = &nnn;
          zz = &zzz;
          numm = &numnum;

          rpg_devroye(xx,nn,zz,numm);     
             
				  Omega(i,j) = *xx;
			}
		}

		//Calculate Z
		for (int i = 0; i < N; ++i)
		{
			for (int j = 0; j < P; ++j)
			{
				Z(i,j) = (YY(i,j)-h)/(2*Omega(i,j));
			}
		}

		//Sample gamma_i
		for (int i = 0; i < N; ++i)
		{
			double Vgamma = 1/(1+sum(Omega.row(i)));

			double Mgamma = Vgamma*(a/niu_a+arma::as_scalar((Z.row(i)-alpha-arma::trans(B*arma::trans(f.row(i))))*arma::trans(Omega.row(i))));
			//double Mgamma = Vgamma*(a+)
			//double Mgamma = Vgamma*(a+ sum(arma::trans(B*arma::trans(f.row(i)))));
			GetRNGstate();
			gamma(i) = as<double>(Rcpp::rnorm(1,Mgamma,sqrt(Vgamma)));
			PutRNGstate();
			 
		}

		//Sample a
		double Va = 1/(N+1/niu_a);
		double Ma = Va*sum(gamma);
		GetRNGstate();
		a = as<double>(Rcpp::rnorm(1,Ma,sqrt(Va)));
		PutRNGstate();

		//Sample alpha_j
		for (int j = 0; j < P; ++j)
		{
			double Valpha = 1/(1/niu_alpha+sum(Omega.col(j)));
			double Malpha = Valpha*arma::as_scalar(mean_alpha(j)+arma::trans((Z.col(j)-gamma-f*arma::trans(B.row(j))))*Omega.col(j));
			//double Malpha = Valpha*sum((Z.col(j)-gamma-f*arma::trans(B.row(j)))%Omega.col(j));
			GetRNGstate();
			alpha(j) = as<double>(Rcpp::rnorm(1,Malpha,sqrt(Valpha)));
			PutRNGstate();
		}

		
		//draw niu
		arma::colvec ms = arma::zeros(K);
		for (int s = 0; s < K; ++s)
		{

			for (int j = (s+1); j < P; ++j)
			{
				if(abs(B(j,s))>0.0001){
					ms(s) = ms(s)+1.0;
					//cout<<"\n Bjs = "<<B(j,s);
				}
			}
			//cout<<"\n ms(s) ="<<ms(s);
			double temp = arma::as_scalar(arma::trans(B.col(s))*B.col(s));
			GetRNGstate();


			niu(s) = 1.0/as<double>(Rcpp::rgamma(1,2.0+ms(s)/2.0,1.0/(2.0+temp/2.0)));
			
			PutRNGstate();

			//draw q
			GetRNGstate();
			q(s) = as<double>(Rcpp::rbeta(1,1.0+ms(s),1.0+P-s-ms(s)));
			
			//cout<<"\n qs(s) ="<<q(s);
			PutRNGstate();

		}

		//Sample B
		for (int s = 0; s < K; ++s)
		{
			arma::mat Bs = B;
			Bs.shed_col(s);
			arma::mat fs = f;
			fs.shed_col(s);
			//cout << "\n f(100,1) rep = "<<f(100,1);
			double Vhat, bhat, prob1,qhat;
			for (int i = 0; i < N; ++i)
			{
				arma::rowvec temp(P);
				temp.fill(gamma(i));
				zhat.row(i) = Z.row(i)-alpha-temp-arma::trans(Bs*arma::trans(fs.row(i)));
			}
			for (int j = 0; j < P; ++j)
			{
				

				if (j<s)
				{
					B(j,s) = 0.0;
					
				}
				else
				{
					Vhat = 1/(1/niu(s)+sum(Omega.col(j)%f.col(s)%f.col(s)));
					bhat = Vhat*sum(f.col(s)%Omega.col(j)%zhat.col(j));
					test = bhat;
					GetRNGstate();
					prob1 = Rcpp::dnorm(NumericVector::create(0.0),test*1.0,sqrt(Vhat))[0];
					PutRNGstate();
					if(prob1 < 0.0000001){
						qhat = 1.0;
					}
					else{
						GetRNGstate();
						double rhat = Rcpp::dnorm(NumericVector::create(0.0),0.0,sqrt(niu(s))*1.0)[0]/prob1;
						PutRNGstate();
						qhat = rhat/((1.0-q(s))/q(s)+rhat);
						//cout << "\n qhat = "<<qhat;
						//cout << "\n rhat = "<<rhat;
						//cout << "\n prob1 = "<<prob1;
						//cout << "\n qs = "<<q(s);
						//qhat = 1.0;
					}

					//sample B_js
					if(j == s){
            
            			RNG rr;

            			GetRNGstate();
            
            			B(j,s) = rr.tnorm(0.0, bhat, sqrt(Vhat));


            			PutRNGstate();
            
					}
					else{
						GetRNGstate();
						double rnum = as<double>(Rcpp::runif(1));
						PutRNGstate();
						//cout<<"\n qhat = "<<qhat;
						if(rnum < qhat){
							GetRNGstate();
							B(j,s) = as<double>(Rcpp::rnorm(1,bhat,sqrt(Vhat)));
							PutRNGstate();
						}
						else{
							B(j,s) = 0.0;
							//B(j,s) = as<double>(Rcpp::rnorm(1,bhat,sqrt(Vhat)));

						}

						
					}
					
				}

			}

		}






		// Continuous Part:
		
		// Sample Delta_c
		arma::mat newYc = arma::zeros(N,Pc);
		for(int i = 0; i < N; ++i)
		{
			arma::rowvec temp(Pc);
			temp.fill(gamma_c(i));
			//for(int j = 0; j<Pc,++j){
				newYc.row(i) = YYc.row(i) - alpha_c - temp - arma::trans(B_c*arma::trans(f.row(i)));

			//}
			
		}
		arma::colvec gamma1 = arma::zeros(Pc);
		arma::colvec gamma2 = arma::zeros(Pc);
		arma::colvec delta = arma::zeros(Pc);
		for( int i = 0; i< Pc; ++i){
			gamma1(i) = (nu0+N)/2.0;
			gamma2(i) =  1.0/(nu0*s02 + arma::as_scalar(arma::trans(YYc.col(i))*YYc.col(i))/2.0);
			GetRNGstate();
			delta(i) = 1/(as<double>(Rcpp::rgamma(1,gamma1(i),gamma2(i))));
			PutRNGstate();
			(Delta_c.col(i)).fill(1.0/delta(i));
		}

		//double gamma1 = (nu0+N)/2.0;
		//double gamma2 = nu0*s02 + arma::as_scalar(arma::trans(YYc)*YYc)/2.0;
		//delta2 = 1/(as<double>(Rcpp::rgamma(1,gamma1,gamma2)));
		//delta2vec.fill(1.0/delta2);


		//Sample alpha_c
		for(int i = 0; i <Pc; ++i){
			double Valpha_c = 1/(1/niu_alpha_c+sum(Delta_c.col(i)));
			double Malpha_c = Valpha_c*arma::as_scalar(arma::trans(YYc.col(i)-gamma_c - f*arma::trans(B_c.row(i)))*Delta_c.col(i));
			GetRNGstate();
			alpha_c(i) = as<double>(Rcpp::rnorm(1,Malpha_c,sqrt(Valpha_c)));
			PutRNGstate();

		}

		//Sample gamma_i_l
		for (int i = 0; i < N; ++i)
		{
			double Vgamma_c = 1/(1+sum(Delta_c.row(i)));

			double Mgamma_c = Vgamma_c*(a_c/niu_a_c+arma::as_scalar((YYc.row(i)-alpha_c-arma::trans(B_c*arma::trans(f.row(i))))*arma::trans(Delta_c.row(i))));
			
			GetRNGstate();
			gamma_c(i) = as<double>(Rcpp::rnorm(1,Mgamma_c,sqrt(Vgamma_c)));
			PutRNGstate();
			 
		}

		//Sample a_c
		double Va_c = 1/(N+1/niu_a_c);
		double Ma_c = Va_c*sum(gamma_c);
		GetRNGstate();
		a_c = as<double>(Rcpp::rnorm(1,Ma_c,sqrt(Va_c)));
		PutRNGstate();

		

		//Sample B_c_k
		for(int s=0; s<K; ++s){
			arma::mat B_c_s = B_c;
			B_c_s.shed_col(s);
			arma::mat fs = f;
			fs.shed_col(s);
			double Vhat_c, bhat_c;
			arma::mat zhat_c = YYc;
			for (int i = 0; i < N; ++i)
			{
				arma::rowvec temp(Pc);
				temp.fill(gamma_c(i));
				zhat_c.row(i) = YYc.row(i)-alpha_c-temp-arma::trans(B_c_s*arma::trans(fs.row(i)));
			}

			for(int j = 0; j<Pc; ++j){		

				Vhat_c = 1/(1/niu_b_c(s)+sum(Delta_c.col(j)%f.col(s)%f.col(s)));
				bhat_c = Vhat_c*sum(f.col(s)%Delta_c.col(j)%zhat_c.col(j));
				GetRNGstate();
				B_c(j,s) = as<double>(Rcpp::rnorm(1,bhat_c,sqrt(Vhat_c)));
				PutRNGstate();
				
			}



		}


		


		// Logistic Part:

		//Calculate Phi
		for (int i = 0; i < N; ++i)
		{	
			arma::rowvec temp(Pl);
			temp.fill(gamma_l(i));
			Phi.row(i) = alpha_l+temp+arma::trans(B_l*arma::trans(f.row(i)));
		}

		// Sample Omega_l
		for (int i = 0; i < N; ++i)
		{
			for(int j = 0; j<Pl; ++j){
			
        
          double *xx;
          int *nn;
          double *zz;
          int *numm;
    
          double xxx=0.5;
          int nnn=1;
          double zzz=Phi(i,j);
          int numnum=1;
    
          xx=&xxx;
          nn = &nnn;
          zz = &zzz;
          numm = &numnum;

          rpg_devroye(xx,nn,zz,numm);     
             
				  Omega_l(i,j) = *xx;
			}
			
		}

		

		//Calculate Z_l
		for (int i = 0; i < N; ++i)
		{
			for(int j = 0; j<Pl;++j){
			
				Z_l(i,j) = (2*YYl(i,j)-1.0)/(2*Omega_l(i,j));
			}
			
		}


		//Sample gamma_i_l
		for (int i = 0; i < N; ++i)
		{
			double Vgamma_l = 1/(1+sum(Omega_l.row(i)));

			double Mgamma_l = Vgamma_l*(a_l/niu_a_l+arma::as_scalar((Z_l.row(i)-alpha_l-arma::trans(B_l*arma::trans(f.row(i))))*arma::trans(Omega_l.row(i))));
			
			GetRNGstate();
			gamma_l(i) = as<double>(Rcpp::rnorm(1,Mgamma_l,sqrt(Vgamma_l)));
			PutRNGstate();
			 
		}

		double Va_l = 1/(N+1/niu_a_l);
		double Ma_l = Va_l*sum(gamma_l);
		GetRNGstate();
		a_l = as<double>(Rcpp::rnorm(1,Ma_l,sqrt(Va_l)));
		PutRNGstate();

		//Sample alpha_l_j
		for (int j = 0; j < Pl; ++j)
		{
			double Valpha_l = 1/(1/niu_alpha_l+sum(Omega_l.col(j)));
			double Malpha_l = Valpha_l*arma::as_scalar((arma::trans((Z_l.col(j)-gamma_l-f*arma::trans(B_l.row(j))))*Omega_l.col(j)));
			//double Malpha = Valpha*sum((Z.col(j)-gamma-f*arma::trans(B.row(j)))%Omega.col(j));
			GetRNGstate();
			alpha_l(j) = as<double>(Rcpp::rnorm(1,Malpha_l,sqrt(Valpha_l)));
			PutRNGstate();
		}



		//sample B_l_k

		for(int s=0; s<K; ++s){
			arma::mat Bs_l = B_l;
			Bs_l.shed_col(s);
			arma::mat fs = f;
			fs.shed_col(s);
			double Vhat_l, bhat_l;
			for (int i = 0; i < N; ++i)
			{
				arma::rowvec temp(Pl);
				temp.fill(gamma_l(i));
				zhat_l.row(i) = Z_l.row(i)-alpha_l-temp-arma::trans(Bs_l*arma::trans(fs.row(i)));
			}
			for(int j = 0; j<Pl; ++j){		

				Vhat_l = 1/(1/niu_b_l(s)+sum(Omega_l.col(j)%f.col(s)%f.col(s)));
				bhat_l = Vhat_l*sum(f.col(s)%Omega_l.col(j)%zhat_l.col(j));
				GetRNGstate();
				B_l(j,s) = as<double>(Rcpp::rnorm(1,bhat_l,sqrt(Vhat_l)));
				PutRNGstate();
				
			}

		}

	

		//Sample f[i,]

		// Combine B matrix with B_l matrix and B_c matrix  Combine Z matrix with Z_l and YYc

		//arma::rowvec comb_alpha(P+Pl+Pc);
	comb_alpha(arma::span(0,(P-1))) = alpha;
	comb_alpha(arma::span(P,(P+Pl-1))) = alpha_l;
	comb_alpha(arma::span((P+Pl),(P+Pl+Pc-1))) = alpha_c;

	//arma::mat comb_Z(N,(P+Pl+Pc));
	comb_Z(arma::span(0,(N-1)),arma::span(0,(P-1))) = Z;
	comb_Z(arma::span(0,(N-1)),arma::span(P,(P+Pl-1))) = Z_l;
	comb_Z(arma::span(0,(N-1)),arma::span((P+Pl),(P+Pl+Pc-1))) = YYc;



	//arma::mat comb_B((P+Pl+Pc),K);
	comb_B(arma::span(0,(P-1)),arma::span(0,(K-1))) = B;
	comb_B(arma::span(P,(P+Pl-1)),arma::span(0,(K-1))) = B_l;
	comb_B(arma::span((P+Pl),(P+Pl+Pc-1)),arma::span(0,(K-1))) = B_c;

	//arma::mat comb_Omega(N,(P+Pl+1));
	comb_Omega(arma::span(0,(N-1)),arma::span(0,(P-1))) = Omega;
	comb_Omega(arma::span(0,(N-1)),arma::span(P,(P+Pl-1))) = Omega_l;
	comb_Omega(arma::span(0,(N-1)),arma::span((P+Pl),(P+Pl+Pc-1))) = Delta_c;

		
		for (int i = 0; i < N; ++i)
		{
			arma::colvec temp(P+Pl+Pc);
			temp(arma::span(0,(P-1))).fill(gamma(i));
			temp(arma::span(P,(P+Pl-1))).fill(gamma_l(i));
			temp(arma::span((P+Pl),(P+Pl+Pc-1))).fill(gamma_c(i));

			arma::mat tempmat = arma::zeros((P+Pl+Pc),K);
			for(int tempind = 0; tempind < (P+Pl+Pc); ++ tempind){
				tempmat.row(tempind) = comb_Omega(i,tempind)*comb_B.row(tempind);
			}
			arma::mat test = arma::trans(comb_B)*tempmat;
			//arma::mat test = arma::zeros(K,K);
			//test.row(0) = arma::trans(comb_B.col(0))*tempmat;
			//for(int indrow = 1; indrow < K; ++indrow){
			//	test(indrow,arma::span(0,(indrow-1))) = test(arma::span(0,(indrow-1)),indrow);
			//	test(indrow,arma::span((indrow),K)) = arma::trans(comb_B(arma::span((indrow),K),indrow))*tempmat;
			//}


			//arma::mat Ome = diagmat(comb_Omega.row(i));
			//arma::mat test = arma::trans(comb_B)*Ome*comb_B;
			//cout<<"\n BOmeB = "<<test(3,3);

			arma::mat Vf = arma::inv(V+test);

			arma::vec eigval;
			arma::mat eigvec;
			eig_sym(eigval,eigvec,Vf);

			arma::mat tempVf = eigvec*diagmat(sqrt(eigval))*arma::inv(eigvec);

			arma::colvec tempcol = arma::trans(comb_Omega.row(i)%(comb_Z.row(i)-comb_alpha-arma::trans(temp)));
			
			arma::colvec Mf = Vf*(arma::trans(comb_B)*tempcol);
			//Ome*arma::trans(comb_Z.row(i)-comb_alpha-arma::trans(temp));
			GetRNGstate();
			Rcpp::NumericVector drawtemp = Rcpp::rnorm(K,0,1);
			PutRNGstate();
			arma::colvec ftemp(drawtemp.begin(),K,false);
			f.row(i) = arma::trans(Mf+tempVf*ftemp);

		}

		


		




		//Store parameter
		if(iter > (Nburnn-1)){
			BBn.slice(iter-Nburnn) = comb_B;
			FFn.slice(iter-Nburnn) = f;
			Alfn.col(iter-Nburnn) = arma::trans(comb_alpha);
			(Gamn.slice(iter-Nburnn)).col(0) = gamma;
			(Gamn.slice(iter-Nburnn)).col(1) = gamma_l;
			(Gamn.slice(iter-Nburnn)).col(2) = gamma_c;


		}

		cout<<"\n iter = "<<iter;

		






	

	}
	





	//PutRNGstate();



	return Rcpp::List::create(
        //Rcpp::Named("testB") = Vgamma,
        Rcpp::Named("BBn") = BBn,
        Rcpp::Named("FFn") = FFn,
        Rcpp::Named("Alfn") = Alfn,
        Rcpp::Named("Gamn") = Gamn
        //Rcpp::Named("stderr")       = stderrest,
        //Rcpp::Named("testFunction") = f(3)
    ) ;	



	

	





}

// [[Rcpp::export]]
SEXP NBfactor(SEXP Ys, SEXP RPrior, SEXP RInitial, int ntopic, int Ndrawn, int Nburnn){
  
  Rcpp::NumericMatrix Yr(Ys); 				//	Create Rcpp matrix from SEXP
	int N = Yr.nrow(), P = Yr.ncol();			//	dim(YY)

	arma::mat YY(Yr.begin(), N, P, false);   	// reuses memory and avoids extra copy

	int K = ntopic; 								//	No of topics

	// Parameter Setting Prior

	Rcpp::List Prior(RPrior);
	Rcpp::NumericMatrix Vr = Prior["V"];
	arma::mat V(Vr.begin(),K,K,false);

	Rcpp::NumericMatrix V0r = Prior["V0"];
	arma::mat V0(V0r.begin(),K,K,false);

	double a = Rcpp::as<double>(Prior["a"]);
	double h = Rcpp::as<double>(Prior["h"]);
	int niu_a = Rcpp::as<int>(Prior["niu_a"]);
	int niu_alpha = Rcpp::as<int>(Prior["niu_alpha"]);

	Rcpp::NumericVector niuR = Prior["niu"];
	arma::colvec niu(niuR.begin(),K,false);

	Rcpp::NumericVector qR = Prior["q"];
	arma::colvec q(qR.begin(),K,false);

	double c_s = Rcpp::as<double>(Prior["c_s"]);
	double d_s = Rcpp::as<double>(Prior["d_s"]);


	// Initialization

	Rcpp::List Initial = RInitial;

	Rcpp::NumericVector drawsB = Initial["B"];
	arma::mat B(drawsB.begin(),P,K,false);

	Rcpp::NumericVector drawsf = Initial["f"];
	arma::mat f(drawsf.begin(),N,K,false);
	
	Rcpp::NumericVector drawsal = Initial["alpha"];
	arma::rowvec alpha(drawsal.begin(),P,false);
	Rcpp::NumericVector drawga = Initial["gamma"];
	arma::colvec gamma(drawga.begin(),N,false);

	arma::mat Psi = arma::zeros(N,P);
	arma::mat Omega = arma::zeros(N,P);
	arma::mat Z = arma::zeros(N,P);
	arma::mat zhat = arma::zeros(N,P);

	//Gibbs Sampler
	//int Ndrawn = 5; 
	//int Nburnn = 0;

	// Store Parameter
	arma::cube BBn = arma::zeros(P,K,Ndrawn);
	arma::cube FFn = arma::zeros(N,K,Ndrawn);

	arma::mat Alfn = arma::zeros(P,Ndrawn);
	arma::mat Gamn = arma::zeros(N,Ndrawn);

	double test;

	//Iteration
	for (int iter = 0; iter < (Ndrawn+Nburnn); ++iter)
	{
		//Calculate Psi
		for (int i = 0; i < N; ++i)
		{
			arma::rowvec temp(P);
			temp.fill(gamma[i]);
			Psi.row(i) = alpha + temp + arma::trans(B*arma::trans(f.row(i))); 
		}

		//Sample omega
		for (int i = 0; i < N; ++i)
		{
		  for (int j = 0; j < P; ++j)
			{
        
        
          double *xx1;
          int *nn1;
          double *zz1;
          int *numm1;
    
          double xxx=0.5;
          int nnn=YY(i,j)+h;
          double zzz=Psi(i,j);
          int numnum=1;
    
          xx1=&xxx;
          nn1 = &nnn;
          zz1 = &zzz;
          numm1 = &numnum;

          rpg_devroye(xx1,nn1,zz1,numm1);     
             
				  Omega(i,j) = *xx1;
          
          //Omega(i,j) = 0.01;
			}
      
      
		}

		//Calculate Z
		for (int i = 0; i < N; ++i)
		{
			for (int j = 0; j < P; ++j)
			{
				Z(i,j) = (YY(i,j)-h)/(2*Omega(i,j));
			}
		}

		//Sample gamma_i
		for (int i = 0; i < N; ++i)
		{
			double Vgamma = 1/(1+sum(Omega.row(i)));

			double Mgamma = Vgamma*(a+arma::as_scalar((Z.row(i)-alpha-arma::trans(B*arma::trans(f.row(i))))*arma::trans(Omega.row(i))));
			//double Mgamma = Vgamma*(a+)
			//double Mgamma = Vgamma*(a+ sum(arma::trans(B*arma::trans(f.row(i)))));
			gamma(i) = as<double>(Rcpp::rnorm(1,Mgamma,sqrt(Vgamma)));
			 
		}

		//Sample a
		double Va = 1/(N+1/niu_a);
		double Ma = Va*sum(gamma);
		a = as<double>(Rcpp::rnorm(1,Ma,sqrt(Va)));

		//Sample alpha_j
		for (int j = 0; j < P; ++j)
		{
			double Valpha = 1/(1/niu_alpha+sum(Omega.col(j)));
			double Malpha = Valpha*arma::as_scalar((arma::trans((Z.col(j)-gamma-f*arma::trans(B.row(j))))*Omega.col(j)));
			//double Malpha = Valpha*sum((Z.col(j)-gamma-f*arma::trans(B.row(j)))%Omega.col(j));
			alpha(j) = as<double>(Rcpp::rnorm(1,Malpha,sqrt(Valpha)));
		}

		//Sample f[i,]
		for (int i = 0; i < N; ++i)
		{
			arma::rowvec temp(P);
			temp.fill(gamma[i]);
			arma::mat Ome = diagmat(Omega.row(i));
			arma::mat Vf = arma::inv(arma::inv(V)+arma::trans(B)*Ome*B);
			arma::colvec Mf = Vf*arma::trans(B)*Ome*arma::trans(Z.row(i)-alpha-temp);
			Rcpp::NumericVector drawtemp = Rcpp::rnorm(K,0,1);
			arma::colvec ftemp(drawtemp.begin(),K,false);
			f.row(i) = arma::trans(Mf+chol(Vf)*ftemp);

		}

		//Sample V

		//Sample B
		for (int s = 0; s < K; ++s)
		{
			arma::mat Bs = B;
			Bs.shed_col(s);
			arma::mat fs = f;
			fs.shed_col(s);
			double Vhat, bhat, prob1,qhat;
			for (int i = 0; i < N; ++i)
			{
				arma::rowvec temp(P);
				temp.fill(gamma[i]);
				zhat.row(i) = Z.row(i)-alpha-temp-arma::trans(Bs*arma::trans(fs.row(i)));
			}
			for (int j = 0; j < P; ++j)
			{
				if (j<s)
				{
					B(j,s) = 0.0;
				}
				else
				{
					Vhat = 1/(1/niu(s)+sum(Omega.col(j)%f.col(s)%f.col(s)));
					bhat = Vhat*sum(f.col(s)%Omega.col(j)%zhat.col(j));
					test = bhat;
					prob1 = Rcpp::dnorm(NumericVector::create(0.0),test*1.0,sqrt(Vhat))[0];
					if(prob1 < 0.00001){
						qhat = 1.0;
					}
					else{
						double rhat = Rcpp::dnorm(NumericVector::create(0.0),0.0,niu(s)*1.0)[0]/prob1;
						qhat = rhat/((1.0-q(s))/q(s)+rhat);
					}

					//sample B_js
					if(j == s){
            
            			RNG rr1;

            			GetRNGstate();
            
            			B(j,s) = rr1.tnorm(0.0, bhat, sqrt(Vhat));


            			PutRNGstate();
            
					}
					else{
						double rnum = as<double>(Rcpp::runif(1));
						if(rnum < qhat){
							B(j,s) = as<double>(Rcpp::rnorm(1,bhat,sqrt(Vhat)));
						}
						else{
							B(j,s) = 0.0;
						}
					}
					
				}
			}
		}

		//draw niu
		arma::colvec ms = arma::zeros(K);
		for (int s = 0; s < K; ++s)
		{
			for (int j = (s+1); j < P; ++j)
			{
				if(abs(B(j,s))>1e-100){
					ms(s) = ms(s)+1.0;
				}
			}
			double temp = arma::as_scalar(arma::trans(B.col(s))*B.col(s));
			niu(s) = 1/as<double>(Rcpp::rgamma(1,(2+ms(s))/2,1.0/((2.0+temp)/2)));

			//draw q
			q(s) = as<double>(Rcpp::rbeta(1,1+ms(s),1.0+P-s-ms(s)));

		}

		//Store parameter
		if(iter > (Nburnn-1)){
			BBn.slice(iter-Nburnn) = B;
			FFn.slice(iter-Nburnn) = f;
			Alfn.col(iter-Nburnn) = arma::trans(alpha);
			Gamn.col(iter-Nburnn) = gamma;

		}

		cout<<"\n iter = "<<iter;

		






	

	}
	









	return Rcpp::List::create(
        //Rcpp::Named("testB") = Vgamma,
        Rcpp::Named("BBn") = BBn,
        Rcpp::Named("FFn") = FFn,
        Rcpp::Named("Alfn") = Alfn,
        Rcpp::Named("Gamn") = Gamn
        //Rcpp::Named("stderr")       = stderrest,
        //Rcpp::Named("testFunction") = f(3)
    ) ;	



	

	





}



