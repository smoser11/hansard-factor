#ifndef _COMBFACTOR_COMBFACTOR_H
#define _COMBFACTOR_COMBFACTOR_H

#include <RcppArmadillo.h>

RcppExport SEXP CombFactor() ;

#endif
