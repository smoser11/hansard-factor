// So that you can inlclude RNG.h instead of RNG.hpp.

#ifndef __RNGWRAP__
#define __RNGWRAP__

#include "RNG.hpp"

#endif
